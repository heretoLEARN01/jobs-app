export default function Jobs(): import("react/jsx-runtime").JSX.Element;
